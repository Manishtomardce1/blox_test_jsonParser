package jsonToJavaObject;

import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.junit.Test;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.test.model.Employee;
import com.test.parseJson.JsonToObject;

public class JsonParserTest {
	
	@Test
	public void parseJsonToObject() throws JsonParseException, JsonMappingException, IOException {
		File file = new File("src/main/resources/files/Employee.json");
		Employee employee = JsonToObject.parseJsonStringToObject(file);
		assertTrue(employee.getName().equals("ABC"));
	}
	
	@Test
	public void parseJsonToObjectList() throws JsonParseException, JsonMappingException, IOException {
		File file = new File("src/main/resources/files/EmployeeList.json");
		List<Employee> employee = JsonToObject.parseJsonStringToObjectList(file);
		assertTrue(employee.size() == 3);
	}

}
