package com.test.model;

import java.util.ArrayList;
import java.util.List;


public class Employee {
	private int id;
	private String name;
	private double salary;
	private List<String> technologies = new ArrayList<>();
	
	public Employee() {}
	
	public Employee(int id, String name, double salary, List<String> technologies) {
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.technologies = technologies;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public List<String> getTechnologies() {
		return technologies;
	}
	public void setTechnologies(List<String> technologies) {
		this.technologies = technologies;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + ", technologies=" + technologies + "]";
	}
	
	


}
