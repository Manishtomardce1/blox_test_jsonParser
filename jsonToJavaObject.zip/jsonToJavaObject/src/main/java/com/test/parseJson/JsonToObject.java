package com.test.parseJson;

import java.io.*;
import java.util.*;

import com.test.model.Employee;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.exc.StreamReadException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.*;


public class JsonToObject {
   public static void main(String args[]) throws IOException{
	   File file1 = new File("src/main/resources/files/Employee.json");
	   File file2 = new File("src/main/resources/files/EmployeeList.json");
	   
	   
	   Employee employee = parseJsonStringToObject(file1);
	   System.out.println(employee.toString());
	   
	   
	   List<Employee> employeeList = parseJsonStringToObjectList(file2);
	   for(Employee emp : employeeList) {
		   System.out.println(emp.toString());
	   }
	   
	   
	   Map<String, Object> map = parseJsontoMap(file1);
	   for(String str : map.keySet()) {
		   System.out.println(str + " "+ map.get(str));
	   }
   }
   
   public static Employee parseJsonStringToObject(File file) throws JsonParseException, JsonMappingException, IOException {
		System.out.println("Parsing JSON to Object:");
		
		ObjectMapper mapper = new ObjectMapper();
	    Employee employee = mapper.readValue(file, Employee.class);
	    return employee;
		
	}
   
   public static List<Employee> parseJsonStringToObjectList(File file) throws JsonParseException, JsonMappingException, IOException {
		System.out.println("Parsing JSON to Object List:");
		
		ObjectMapper mapper = new ObjectMapper();
	    List<Employee> employeeList = mapper.readValue(file, new TypeReference<List<Employee>> () {});
	    return employeeList;
		
	}

	
   public static Map<String, Object> parseJsontoMap(File file) throws StreamReadException, DatabindException, IOException {
	   System.out.println("Parsing JSON to Object List:");
		
		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> map = mapper.readValue(file, new TypeReference<Map<String, Object>> () {});
	    return map;
   }


   
   
   
}






